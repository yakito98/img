<?


$jieshaos=file("./url.txt");
 
$jieshaoc=count($jieshaos);

//echo $jieshaoc;

$jieshaor=rand(0,$jieshaoc - 1);
//echo $jieshaor;
$jieshao=@$jieshaos[$jieshaor];
 
//echo "$jieshao";

header("location:$jieshao");





?>